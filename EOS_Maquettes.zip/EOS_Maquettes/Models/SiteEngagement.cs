﻿using System.ComponentModel;

namespace EOS_Maquettes.Models
{
    public class SiteEngagement
    {
        [DisplayName("Opération Spéciale")]
        public string SpecialOperation { get; set; }

        [DisplayName("Statut")]
        public string Status { get; set; }

        [DisplayName("Avancement")]
        public int Sites { get; set; }

    }
}
