﻿namespace EOS_Maquettes.Models
{
    public class Site
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public string Type { get; set; }
        public string Region { get; set; }
    }
}
