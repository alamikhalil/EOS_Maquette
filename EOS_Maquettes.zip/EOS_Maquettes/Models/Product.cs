﻿namespace EOS_Maquettes.Models
{
    public class Product
    {
        public int InternalCode { get; set; }
        public string Name { get; set; }
        public string Department { get; set; }
        public string Shelf { get; set; }
        public string SubFamily { get; set; }
        public string SubSubFamily { get; set; }
        public string Supplier { get; set; }
        public string SupplierState { get; set; }
        public string UNCS { get; set; }
        public string EAN { get; set; }
        public string LifeCycleAttribute { get; set; }
        public string ProductCycle { get; set; }
        public int Depth { get; set; }
        public string State { get; set; }
        public string VAT { get; set; }
        public string DeliveryValue { get; set; }
        public int Package { get; set; }
        public string Seasonality { get; set; }
        public float Elasticity { get; set; }
        public string ProductRole { get; set; }
        public bool TopList { get; set; }
    }
}
