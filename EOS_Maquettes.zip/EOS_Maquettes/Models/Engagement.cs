﻿using System.ComponentModel;

namespace EOS_Maquettes.Models
{
    public class Engagement
    {
        [DisplayName("Code GOLD")]

        public int Id { get; set; }

        //public SpecialOperationProduct SpecialOperationProduct { get; set; }
        //public Site Site { get; set; }

        [DisplayName("Produit")]
        public string SpecialOperationProduct { get; set; }

        [DisplayName("Site")]
        public string Site { get; set; }
        [DisplayName("Quantité")]
        public int Quantity { get; set; }
    }
}
