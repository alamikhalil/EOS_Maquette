﻿namespace EOS_Maquettes.Models
{
    public class Region
    {
        public int Id { get; set; }
        public Franchise Franchise { get; set; }
        public string Name { get; set; }
    }
}
