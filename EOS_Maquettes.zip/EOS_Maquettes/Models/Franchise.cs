﻿namespace EOS_Maquettes.Models
{
    /// <summary>
    /// FR: Enseigne
    /// </summary>
    public class Franchise
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
