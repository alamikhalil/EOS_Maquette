﻿namespace EOS_Maquettes.Models
{
    public class SpecialOperationProduct
    {
        public int Id { get; set; }
        public SpecialOperation SpecialOperation { get; set; }
        public Product Product { get; set; }
        public decimal Discount { get; set; }
        public decimal PurchasePriceDiscounted { get; set; }
        public string Communication { get; set; }
        public string LoyaltyProgram { get; set; }
    }
}
