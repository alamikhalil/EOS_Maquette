﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace EOS_Maquettes.Models
{
    public class SpecialOperation
    {
        [DisplayName("Code GOLD")]
        public int Id { get; set; }

        [DisplayName("Code GOLD")]
        public string Code { get; set; }

        [DisplayName("Nom")]
        public string Name { get; set; }

        [DisplayName("Date début")]
        [DisplayFormat(DataFormatString = "{0:d}")]
        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }

        [DisplayName("Date fin")]
        [DisplayFormat(DataFormatString = "{0:d}")]
        [DataType(DataType.Date)]
        public DateTime EndDate { get; set; }

        [DisplayName("Produits")]
        public List<Product>? Products { get; set; }

        [DisplayName("Date début période précédente")]
        [DisplayFormat(DataFormatString = "{0:d}")]
        [DataType(DataType.Date)]
        public DateTime PreviousPeriodStartDate { get; set; }

        [DisplayName("Date fin période précédente")]
        [DisplayFormat(DataFormatString = "{0:d}")]
        [DataType(DataType.Date)]
        public DateTime PreviousPeriodEndDate { get;set; }
    }
}
