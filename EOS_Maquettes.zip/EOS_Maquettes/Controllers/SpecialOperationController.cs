﻿using EOS_Maquettes.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ClosedXML.Excel;

namespace EOS_Maquettes.Controllers
{
    public class SpecialOperationController : Controller
    {


        // GET: SpecialOperation
        public ActionResult Index()
        {
            var SpecOps = new List<SpecialOperation>()
            {
                new SpecialOperation()
                {
                    Id= 2,
                    Name = "Ramadan",
                    StartDate = new DateTime(2023, 4, 1),
                    EndDate = new DateTime(2023, 4, 20),
                    Products= new List<Product>()
                    {
                        new Product()
                        {
                            InternalCode= 3,
                            Name="P3"
                        },
                        new Product()
                        {
                            InternalCode= 4,
                            Name="P4"
                        }
                    }
                },
                new SpecialOperation()
                {
                    Id= 1,
                    Name = "Promo Hiver",
                    StartDate = new DateTime(2023, 1, 1),
                    EndDate = new DateTime(2023, 2, 1),
                    Products= new List<Product>()
                    {
                        new Product()
                        {
                            InternalCode= 1,
                            Name="P1"
                        },
                        new Product()
                        {
                            InternalCode= 2,
                            Name="P2"
                        }
                    }
                }

            };

            return View(SpecOps);
        }

        // GET: SpecialOperation/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: SpecialOperation/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: SpecialOperation/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: SpecialOperation/Edit/5
        public ActionResult Edit(int id)
        {
            var model = new SpecialOperation()
            {
                Id = 1,
                Name = "Promo Hiver",
                StartDate = new DateTime(2023, 1, 1),
                EndDate = new DateTime(2023, 2, 1),
                PreviousPeriodEndDate = new DateTime(2022, 1, 5),
                PreviousPeriodStartDate = new DateTime(2022, 2, 10),
                Products = new List<Product>()
                    {
                        new Product()
                        {
                            InternalCode= 1,
                            Name="P1"
                        },
                        new Product()
                        {
                            InternalCode= 2,
                            Name="P2"
                        }
                    }
            };
            return View(model);
        }

        // POST: SpecialOperation/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            var fileName = "C:\\Folder1\\Prev.xlsx";
            var workbook = new XLWorkbook(fileName);


            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: SpecialOperation/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: SpecialOperation/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
