﻿using EOS_Maquettes.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EOS_Maquettes.Controllers
{
    public class EngagementController : Controller
    {
        // GET: EngagementController
        public ActionResult Index()
        {
            var engagements = new List<Engagement>
            {
                new Engagement
                {
                    Site = "1",
                    SpecialOperationProduct= "Sidi Ali",
                    Quantity = 200
                },
                new Engagement
                {
                    Site = "1",
                    SpecialOperationProduct = "Ain Saiss",
                    Quantity = 300
                }
            };
            return View(engagements);
        }

        public ActionResult Liste()
        {

            return View();
        }

        // GET: EngagementController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: EngagementController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: EngagementController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EngagementController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: EngagementController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EngagementController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: EngagementController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
