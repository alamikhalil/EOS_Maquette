﻿using EOS_Maquettes.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EOS_Maquettes.Controllers
{
    public class SiteEngagementController : Controller
    {
        // GET: SiteEngagement
        public ActionResult Index()
        {
            var se = new List<SiteEngagement>
            {
                new SiteEngagement
                {
                    SpecialOperation = "RAMADAN23",
                    Sites = 42,
                    Status = "En cours"
                },
                new SiteEngagement
                {
                    SpecialOperation = "ÉTÉ 2023",
                    Sites = 42,
                    Status = "En cours"
                },
                new SiteEngagement
                {
                    SpecialOperation = "HIVER 2023",
                    Sites = 53,
                    Status = "Terminée"
                }
            };
            return View(se);
        }

        // GET: SiteEngagement/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: SiteEngagement/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: SiteEngagement/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: SiteEngagement/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: SiteEngagement/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: SiteEngagement/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: SiteEngagement/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
